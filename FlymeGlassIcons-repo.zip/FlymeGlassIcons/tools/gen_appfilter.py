"""Regenerate appfilter.xml and drawable.xml from components.csv.
Fill the 'activity' column for icons that are still empty, then run:
    python3 tools/gen_appfilter.py
"""
import csv, os
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rows = list(csv.DictReader(open(os.path.join(root, "tools", "components.csv"))))
af = ['<?xml version="1.0" encoding="utf-8"?>', '<resources>', '    <scale factor="1.0" />']
for r in rows:
    if r["activity"].strip():
        af.append('    <item component="ComponentInfo{%s/%s}" drawable="%s" />' % (r["package"], r["activity"].strip(), r["drawable"]))
af.append('</resources>')
text = "\n".join(af)
for p in ("app/src/main/res/xml/appfilter.xml", "app/src/main/assets/appfilter.xml"):
    open(os.path.join(root, p), "w").write(text)
dl = ['<?xml version="1.0" encoding="utf-8"?>', '<resources>', '    <version>1</version>', '    <category title="All" />']
dl += ['    <item drawable="%s" />' % r["drawable"] for r in rows]
dl.append('</resources>')
open(os.path.join(root, "app/src/main/assets/drawable.xml"), "w").write("\n".join(dl))
print("done:", len(rows), "icons")
