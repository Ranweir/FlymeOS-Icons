# Glass Icons (icon pack)

Android icon pack made from a Xiaomi `.mtz` theme's `icons` file. For personal use.

## APK banane ka tareeka (phone se bhi)
1. Is repo ko GitHub par upload karo.
2. **Actions** tab, **Build APK**, **Run workflow**.
3. Build khatam hone par **Artifacts** se `GlassIcons-debug-apk` download karo, zip kholo, APK install karo.
4. Launcher (Nova, Lawnchair, etc.) ki settings mein Icon pack, Glass Icons select karo.

## Dhyan do
- Icons 512x512 PNG mein convert hue hain (`res/drawable-nodpi`).
- `appfilter.xml` mein activity names mostly best-guess hain. Agar koi icon apply na ho, `tools/components.csv` mein sahi activity daalo aur `python3 tools/gen_appfilter.py` chalao.
- Ye icons abhi bina activity ke hain, to unpar icon lagne ke liye pehle activity daalni hogi:
- com.google.android.apps.wellbeing
- com.instagram.android
- com.mi.android.globalFileexplorer
- com.mi.global.bbs
- com.mi.globalbrowser
- com.mi.globalminusscreen
- com.mi.health
- com.mipay.wallet
- com.miui.bugreport
- com.miui.home
- com.miui.miservice
- com.miui.supermarket
- com.miui.voiceassist
- com.ss.android.ugc.trill
- com.xiaomi.discover
- com.xiaomi.finddevice
- com.xiaomi.gamecenter
- com.xiaomi.gamecenter.sdk.service
- com.xiaomi.glgm
- com.xiaomi.midrop
- com.xiaomi.mipicks
- com.xiaomi.wearable
- jp.pxv.android
- mark.via.gp
- tw.nekomimi.nekogram
- MIUI ke dynamic calendar/clock (`fancy_icons`) aur `icon_mask` is pack mein shamil nahi hain, kyunki Android launchers unhe support nahi karte.
- Package name `com.example.iconpack` ko apne naam se badal lo (`app/build.gradle` aur manifest).
